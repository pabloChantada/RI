# Chipichanti
- Continuar memoria
- Pequeño bug en los ultimos episodios (Seguramente sea por falta de sleeps en el codigo
y sobrecarga de mensajes)
- Espabilar

# Lau
- Ya hizo todo es la mejor
